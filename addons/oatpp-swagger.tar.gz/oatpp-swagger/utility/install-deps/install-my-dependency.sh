#!/bin/sh

echo "steps to install some my dependency"
